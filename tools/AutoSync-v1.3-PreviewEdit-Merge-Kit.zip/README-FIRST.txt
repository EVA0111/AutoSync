AutoSync v1.3 + Preview & Edit — ZIP merge kit
================================================
This is a ZIP of the merger, NOT a complete prebuilt portable app.

1. Extract these files into your EXISTING AutoSync v1.3 portable folder,
   right next to AutoSync.exe (keep the two script files together).
2. Double-click Make-AutoSync-v1.3-PreviewEdit.cmd.
3. It downloads the Preview & Edit shell, copies your REAL v1.3 engine
   and Python runtime, and creates a NEW portable folder and ZIP beside
   your existing installation.
4. Run AutoSync.exe in the new folder.
5. Keep the original v1.3 folder until case 1 is verified.

The helper checks SHA-256 hashes for critical engine files. Your original
installation remains unchanged. Requires internet for the GUI download.

NOTES: The merged Windows application has not been tested end-to-end
against case 1. Editor compatibility with the full v1.3 engine is not
guaranteed. The GUI may still show a legacy v1.1 label, even though the
engine is copied from your v1.3 installation.
