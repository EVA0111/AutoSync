AutoSync v1.3 + Preview & Edit — Windows ZIP merge kit
========================================================
This ZIP contains the merger only, NOT the prebuilt portable application.

1. Extract these scripts into the folder containing your genuine AutoSync
   v1.3 AutoSync.exe (not a v1.2 folder).
2. Double-click Make-AutoSync-v1.3-PreviewEdit.cmd.
3. It downloads the Preview & Edit GUI, copies the genuine v1.3 engine and
   Python runtime, and creates a NEW portable folder and ZIP in the parent
   directory. Your existing installation is not overwritten.

FIX: The CMD launcher now passes "%~dp0." to avoid the trailing-backslash
quote parsing error. The PowerShell script also strips stray quotation
marks from incoming path arguments.

This is an unverified GUI/engine combination. Verify synchronization
with your own case 1 media before relying on exports.
